<template>
  <router-link to="/">
    <div>
      <img src="../assets/main.png">
    </div>
  </router-link>
</template>

<script>
export default {
  name: 'Icon'
}
</script>

<style scoped>

div {
  text-align: center;
  padding-top: 10px;
  padding-bottom: 5px;
}

</style>